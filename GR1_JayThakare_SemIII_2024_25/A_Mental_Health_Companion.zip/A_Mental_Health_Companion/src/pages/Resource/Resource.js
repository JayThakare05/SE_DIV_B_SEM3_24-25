import React from 'react';
import './resource.css';

const Resource = () => {
   
   return(
    <>
    <div className="doc">

   <h1 className='ress1'>Resources</h1>
   <h3 className='ress2'> You can explore your symptoms here</h3>
    <div className="documentry">
<p>
1 in 5 adults and 1 in 6 young people experience a mental health disorder every year in the United States.  May is Mental Health Awareness Month, where organizations across the country seek to spread awareness, dispel stigma, and provide help. Mental health is a widespread problem. With such prevalence in the U.S., if you don't suffer from a mental health disorder yourself, chances are you know someone who does. Provided on this guide are resources to learn more about mental health and to provide help to you or your loved ones.
</p>
<p>
   Some Mental Health Disorders are:
</p>
<div className="disorders">
<b>Generalized Anxiety Disorder (GAD)</b>
<p> Generalized Anxiety Disorder (GAD) is characterized by persistent and excessive worry about a number of different things. People with GAD may anticipate disaster and may be overly concerned about money, health, family, work, or other issues. Individuals with GAD find it difficult to control their worry. They may worry more than seems warranted about actual events or may expect the worst even when there is no apparent reason for concern.
GAD is diagnosed when a person finds it difficult to control worry on more days than not for at least six months and has three or more symptoms. This differentiates GAD from worry that may be specific to a set stressor or for a more limited period of time.
GAD affects 6.8 million adults, or 3.1% of the U.S. population, in any given year. Women are twice as likely to be affected.
</p>
<b>Obsessive-Compulsive Disorder(OCD)</b>
<p> Obsessive-compulsive disorder (OCD) is a long-lasting disorder in which a person experiences uncontrollable and recurring thoughts (obsessions), engages in repetitive behaviors (compulsions), or both. People with OCD have time-consuming symptoms that can cause significant distress or interfere with daily life. However, treatment is available to help people manage their symptoms and improve their quality of life. <br />
   Some Symptoms are:
   <ul>
   <li>Fear of germs or contamination </li>
   <li>Fear of forgetting, losing, or misplacing something </li>
   <li>Fear of losing control over one’s behavior </li>
   <li>Aggressive thoughts toward others or oneself </li>
   <li>Unwanted, forbidden, or taboo thoughts involving sex, religion, or harm </li>
   <li>Desire to have things symmetrical or in perfect order</li>
   <li>Excessive cleaning or handwashing</li>
<li>Ordering or arranging items in a particular, precise way</li>
   </ul>
</p>
<b>Post-traumatic stress disorder (PTSD)</b>
<p> Post-traumatic stress disorder (PTSD) is a mental health condition that's caused by an extremely stressful or terrifying event — either being part of it or witnessing it. Symptoms may include flashbacks, nightmares, severe anxiety and uncontrollable thoughts about the event.Getting treatment after PTSD symptoms arise can be very important to ease symptoms and help people function better. <br />
Some Symptoms are:
<ul>
   <li>Unwanted, distressing memories of a traumatic event that come back over and over again.</li>
   <li>Self-destructive behavior, such as drinking too much or driving too fast.</li>
   <li>Upsetting dreams or nightmares about a traumatic event.</li>
   <li>Severe emotional distress or physical reactions to something that reminds you of a traumatic event.</li>
   <li>Trying not to think or talk about a traumatic event.</li>
   <li>Staying away from places, activities or people that remind you of a traumatic event.</li>
   <li>Negative thoughts about yourself, other people or the world.</li>
<li>Memory problems, including not remembering important aspects of a traumatic event.</li>
   </ul>
</p>
<b>Panic Disorder</b>
<p> Panic disorder is a type of anxiety disorder. It causes repeated panic attacks, which are sudden periods of intense fear, discomfort, or a sense of losing control. These attacks happen even though there is no real danger. They often cause physical symptoms. For example, you may have a rapid or pounding heartbeat and feel like you are having a heart attack.

If you have panic attacks, it doesn't mean you will develop a panic disorder. Many people only have one or two panic attacks in their lifetime and get better without treatment. <br />
   Some Symptoms are:
   <ul>
   <li>Sudden and repeated panic attacks of overwhelming anxiety and fear </li>
   <li>A feeling of being out of control or a fear of death during a panic attack </li>
   <li>An intense worry about another panic attack</li>
   <li>A fear or avoidance of places and situations where they had panic attacks in the past</li>
   <li>Physical symptoms during a panic attack, such as</li>
   <ul>
   <li>Pounding or racing heart</li>
   <li>Sweating or chills</li>
   <li>Stomach pain or nausea</li>
<li>Weakness or dizziness</li>
</ul>
   </ul>
</p>
<b>Social Anxiety Disorder(SAD)</b>
<p> Social anxiety disorder is a common type of anxiety disorder. A person with social anxiety disorder feels symptoms of anxiety or fear in situations where they may be scrutinized, evaluated, or judged by others, such as speaking in public, meeting new people, dating, being on a job interview, answering a question in class, or having to talk to a cashier in a store. Doing everyday things, such as eating or drinking in front of others or using a public restroom, also may cause anxiety or fear due to concerns about being humiliated, judged, and rejected. <br />
   Some Symptoms are:
   <ul>
   <li>Blush, sweat, or tremble.</li>
   <li>Have a rapid heart rate.</li>
   <li>Feel their “mind going blank,” or feel sick to their stomach.</li>
   <li>Have a rigid body posture, or speak with an overly soft voice.</li>
   <li>Feel self-consciousness or fear that people will judge them negatively.</li>
   <li>Avoid places where there are other people.</li>
  </ul>
</p>
<b>Major depression</b>
<p> In major depression, the most prominent symptom is a severe and persistent low mood, profound sadness, or a sense of despair. The mood can sometimes appear as irritability. Or the person suffering major depression may not be able to enjoy activities that are usually enjoyable.

Major depression is more than just a passing blue mood, a "bad day," or temporary sadness. The symptoms of major depression are defined as lasting at least two weeks but usually they go on much longer — months or even years.

 <br />
   Some Symptoms are:
   <ul>
   <li>Distinctly depressed or irritable mood.</li>
   <li>Loss of interest or pleasure.</li>
   <li>Decreased or increased weight or appetite.</li>
   <li>Decreased or increased sleep.</li>
   <li>Fatigue and loss of energy</li>
   <li>Thoughts of death, suicide attempts or plans.</li>
  </ul>
</p>
<b>Bipolar Disorder</b>
<p>Bipolar disorder (formerly called manic-depressive illness or manic depression) is a mental illness that causes unusual shifts in a person’s mood, energy, activity levels, and concentration. These shifts can make it difficult to carry out day-to-day tasks.

There are three types of bipolar disorder. All three types involve clear changes in mood, energy, and activity levels.  These moods range from periods of extremely “up,” elated, irritable, or energized behavior (known as manic episodes) to very “down,” sad, indifferent, or hopeless periods (known as depressive episodes). Less severe manic periods are known as hypomanic episodes.

 <br />
   Some Symptoms of manic episodes are:
   <ul>
   <li>Feeling very up, high, elated, or extremely irritable or touchy.</li>
   <li>Feeling jumpy or wired, more active than usual.</li>
   <li>Having a decreased need for sleep.</li>
   <li>Talking fast about a lot of different things (“flight of ideas”).</li>
   <li>Racing thoughts.</li>
  </ul>
  Some Symptoms of depressive episodes are:
   <ul>
   <li>Feeling very down or sad, or anxious.</li>
   <li>Feeling slowed down or restless.</li>
   <li>Having trouble falling asleep, waking up too early, or sleeping too much.</li>
   <li>Feeling unable to do even simple things.</li>
   <li>Having a lack of interest in almost all activities.</li>
  </ul>
</p>
<b>Perinatal Depression</b>
<p> Perinatal depression is a mood disorder that occurs during pregnancy and after childbirth. The symptoms can range from mild to severe. In rare cases, the symptoms are severe enough that a mother and her baby’s health and well-being may be at risk.

Perinatal depression can be treated. Learn about the signs and symptoms, risk factors, treatments, and ways you or a loved one can get help.

 <br />
   Some Symptoms are:
   <ul>
   <li>Persistent sad, anxious, or “empty” mood most of the day, nearly every day, for at least 2 weeks.</li>
   <li>Feelings of hopelessness or pessimism.</li>
   <li>Feelings of irritability, frustration, or restlessness.</li>
   <li>Loss of interest or pleasure in hobbies and activities.</li>
   <li>Being restless or having trouble sitting still</li>
   <li>Persistent doubts about the ability to care for the baby.</li>
  </ul>
</p>
<b>Premenstrual Dysphoric Disorder (PMDD)</b>
<p> Premenstrual dysphoric disorder (PMDD) is a much more severe form of premenstrual syndrome (PMS). It may affect people of childbearing age. It’s a severe and chronic health condition that needs attention and treatment. Lifestyle changes and sometimes medicines can help manage symptoms.The exact cause of PMDD is not known. It may be an abnormal reaction to normal hormone changes that happen with each menstrual cycle. The hormone changes can cause a serotonin deficiency. Serotonin is a substance found naturally in the brain and intestines that narrows blood vessels and can affect mood and cause physical symptoms.

 <br />
   Some Symptoms are:
   <ul>
   <li>Depressed mood, sadness, hopelessness, or feelings of worthlessness.</li>
   <li>Increased anxiety, tension, or the feeling of being on edge all the time.</li>
   <li>Mood swings.</li>
   <li>Self-critical thoughts, increased sensitivity to rejection.</li>
   <li>Frequent or sudden tearfulness.</li>
   <li>Fatigue, lethargy, or lack of energy.</li>
  </ul>
</p>
</div>
    </div>
    
    </div>
    </>
   )
}
export default Resource;