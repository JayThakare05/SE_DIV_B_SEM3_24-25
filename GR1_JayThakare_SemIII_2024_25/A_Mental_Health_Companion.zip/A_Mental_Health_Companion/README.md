*To run this just do* 
*Download the npm modules*
by *npx install react react-dom*
then
npm start in respective folder through *terminal* 
and at *localhost:3000*